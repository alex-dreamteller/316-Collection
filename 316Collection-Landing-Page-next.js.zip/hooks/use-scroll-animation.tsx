"use client"

import React from "react"
import { useEffect, useRef, useState } from "react"

export function useScrollAnimation(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        // Update visibility both ways - fade in when entering, fade out when leaving
        setIsVisible(entry.isIntersecting)
      },
      { threshold, rootMargin: "-50px 0px" }
    )

    const currentRef = ref.current
    if (currentRef) observer.observe(currentRef)

    return () => {
      if (currentRef) observer.unobserve(currentRef)
    }
  }, [threshold])

  return { ref, isVisible }
}

export function useInViewGlow(threshold = 0.5) {
  const ref = useRef<HTMLButtonElement>(null)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsInView(entry.isIntersecting),
      { threshold }
    )

    const currentRef = ref.current
    if (currentRef) observer.observe(currentRef)

    return () => {
      if (currentRef) observer.unobserve(currentRef)
    }
  }, [threshold])

  return { ref, isInView }
}

export function AnimatedSection({ 
  children, 
  className = "",
  delay = 0 
}: { 
  children: React.ReactNode
  className?: string
  delay?: number
}) {
  const { ref, isVisible } = useScrollAnimation(0.05)

  return (
    <div
      ref={ref}
      className={`transition-all duration-500 ease-out ${className}`}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "translateY(0)" : "translateY(20px)",
        transitionDelay: `${delay}ms`
      }}
    >
      {children}
    </div>
  )
}

export function GlowButton({ 
  children, 
  onClick,
  className = "",
  type = "button"
}: { 
  children: React.ReactNode
  onClick?: () => void
  className?: string
  type?: "button" | "submit"
}) {
  const { ref, isInView } = useInViewGlow()

  return (
    <button
      ref={ref}
      type={type}
      onClick={onClick}
      className={`${className} ${isInView ? 'animate-soft-pulse' : ''}`}
    >
      {children}
    </button>
  )
}
